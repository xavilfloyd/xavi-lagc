from PyQt5.QtCore import QPoint
from qgis.core import (
    QgsVectorLayer
)

from qgis.gui import (
    QgsMapCanvas,
    QgsMapTool
)

from PyQt5.QtWidgets import QLineEdit

class PointTool(QgsMapTool, QLineEdit):   
    def __init__(self, canvas, xlonmin, xlonmax, ylatmin, ylatmax):
        QgsMapTool.__init__(self, canvas)
        self.canvas = canvas
        self.xlonmin = xlonmin
        self.xlonmax = xlonmax
        self.ylatmin = ylatmin
        self.ylatmax = ylatmax
        
        self.x1 = 0
        self.y1 = 0

        self.x2 = 0
        self.y2 = 0  

        self.contador = 1

        self.point = QPoint(0,0)

    def canvasPressEvent(self, event):
        pass

    def canvasMoveEvent(self, event):
        x = event.pos().x()
        y = event.pos().y()

        point = self.canvas.getCoordinateTransform().toMapCoordinates(x, y)

    def canvasReleaseEvent(self, event):
        #Get the click
        if self.contador == 1:
            self.x1 = event.pos().x()
            self.y1 = event.pos().y()
            self.contador+=1
        else:
            self.x2 = event.pos().x()
            self.y2 = event.pos().y()
            self.contador = 0

        self.point1 = self.canvas.getCoordinateTransform().toMapCoordinates(self.x1, self.y1)
        self.point2 = self.canvas.getCoordinateTransform().toMapCoordinates(self.x2, self.y2)
        
        self.rellenaLineEdit()     
      
    def rellenaLineEdit(self):
        if self.point1.x() > self.point2.x():
            self.xlonmin.setText(str(self.point1.x()))
            self.xlonmax.setText(str(self.point2.x()))
        else:
            self.xlonmin.setText(str(self.point2.x()))
            self.xlonmax.setText(str(self.point1.x()))
        
        if self.point1.y() > self.point2.y():
            self.ylatmin.setText(str(self.point1.y()))
            self.ylatmax.setText(str(self.point2.y()))
        else:
            self.ylatmin.setText(str(self.point2.y()))
            self.ylatmax.setText(str(self.point1.y()))

    def activate(self):
        pass

    def deactivate(self):
        pass

    def isZoomTool(self):
        return False

    def isTransient(self):
        return False

    def isEditTool(self):
        return True
